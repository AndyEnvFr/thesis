"as.treeshape" <-
function (x, ...) UseMethod("as.treeshape")

