/*
 * debug.h - convenience header for debug settings ... suggest including other messaging functions here 
 *
 *  Created on: 5.9.15
 *      Author: Florian Hartig
 */

//#ifndef DEBUG
//#define DEBUG
//#endif
