Folder for tests 

Read 

* http://r-pkgs.had.co.nz/tests.html
* http://cran.r-project.org/doc/manuals/r-release/R-exts.html#Writing-package-vignettes
