PhyloSim_vignette <- function(){
  shell.exec(paste(system.file(package="PhyloSim"), "/doc/Vignette_new.pdf", sep=""))
}


